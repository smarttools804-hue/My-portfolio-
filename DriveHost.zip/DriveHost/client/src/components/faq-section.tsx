import { useState } from "react";
import { ChevronDown, ChevronUp } from "lucide-react";
import { Button } from "@/components/ui/button";

interface FAQItem {
  question: string;
  answer: string;
}

const faqData: FAQItem[] = [
  {
    question: "How many combinations will I get?",
    answer: "The tool generates up to 100 unique combinations, prioritizing quality and pronunciation. The exact number depends on the names you enter and their compatibility."
  },
  {
    question: "Can I save my favorites?",
    answer: "Yes! Use the copy button next to each name to save your favorites to your clipboard. You can then paste them into a document or notes app for later consideration."
  },
  {
    question: "What makes a good combination?",
    answer: "The best combinations maintain elements from both names, are easy to pronounce, and feel meaningful to both partners. Our algorithm evaluates phonetic patterns, syllable structure, and overall flow."
  },
  {
    question: "Is my information stored or shared?",
    answer: "No! All name processing happens locally in your browser. Names are stored temporarily in your browser's local storage for your convenience, but no personal information is sent to our servers or shared with third parties."
  }
];

export default function FaqSection() {
  const [openItems, setOpenItems] = useState<number[]>([]);

  const toggleItem = (index: number) => {
    setOpenItems(prev => 
      prev.includes(index) 
        ? prev.filter(i => i !== index)
        : [...prev, index]
    );
  };

  return (
    <section className="py-16 bg-background" data-testid="faq-section">
      <div className="container mx-auto px-4 max-w-4xl">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-serif font-bold mb-4">
            Frequently Asked <span className="gradient-text">Questions</span>
          </h2>
        </div>

        <div className="space-y-4">
          {faqData.map((item, index) => (
            <div key={index} className="bg-card rounded-xl border border-border overflow-hidden">
              <Button
                variant="ghost"
                className="w-full text-left p-6 flex items-center justify-between hover:bg-muted/50 transition-colors h-auto"
                onClick={() => toggleItem(index)}
                data-testid={`button-faq-toggle-${index}`}
              >
                <h3 className="font-semibold text-lg pr-4">{item.question}</h3>
                {openItems.includes(index) ? (
                  <ChevronUp className="w-5 h-5 flex-shrink-0" />
                ) : (
                  <ChevronDown className="w-5 h-5 flex-shrink-0" />
                )}
              </Button>
              
              {openItems.includes(index) && (
                <div className="px-6 pb-6" data-testid={`text-faq-answer-${index}`}>
                  <p className="text-muted-foreground">
                    {item.answer}
                  </p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
