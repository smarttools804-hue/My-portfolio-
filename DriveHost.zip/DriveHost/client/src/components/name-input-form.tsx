import { useState } from "react";
import { Plus, WandSparkles, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { generateCombinations, NameCombination } from "@/lib/name-combiner";
import { useLocalStorage } from "@/hooks/use-local-storage";

interface NameInputFormProps {
  onCombinationsGenerated: (combinations: NameCombination[]) => void;
}

export default function NameInputForm({ onCombinationsGenerated }: NameInputFormProps) {
  const [names, setNames] = useLocalStorage<string[]>("coupleNames", ["", ""]);
  const [isGenerating, setIsGenerating] = useState(false);
  const maxNames = 4;

  const updateName = (index: number, value: string) => {
    const newNames = [...names];
    newNames[index] = value;
    setNames(newNames);
  };

  const addName = () => {
    if (names.length < maxNames) {
      setNames([...names, ""]);
    }
  };

  const removeName = (index: number) => {
    if (names.length > 2) {
      const newNames = names.filter((_: string, i: number) => i !== index);
      setNames(newNames);
    }
  };

  const handleGenerate = async () => {
    const validNames = names.filter((name: string) => name.trim().length > 0);
    
    if (validNames.length < 2) {
      alert("Please enter at least 2 names to combine.");
      return;
    }

    setIsGenerating(true);
    
    // Add a small delay to show loading state
    await new Promise(resolve => setTimeout(resolve, 500));
    
    try {
      const combinations = generateCombinations(validNames);
      onCombinationsGenerated(combinations);
    } catch (error) {
      console.error("Error generating combinations:", error);
      alert("Sorry, there was an error generating combinations. Please try again.");
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <section className="py-16 bg-background" data-testid="name-input-form">
      <div className="container mx-auto px-4 max-w-5xl">
        <div className="bg-card rounded-2xl shadow-xl p-8 md:p-12 border border-border">
          <div className="text-center mb-10">
            <h2 className="text-3xl md:text-4xl font-serif font-bold mb-4">
              Enter Names to Combine
            </h2>
            <p className="text-muted-foreground">
              Add 2-4 names to generate beautiful combinations
            </p>
          </div>

          {/* Name Input Fields */}
          <div className="space-y-4 mb-6">
            {names.map((name: string, index: number) => (
              <div key={index} className="relative">
                <div className="relative">
                  <Input
                    id={`name-${index + 1}`}
                    type="text"
                    value={name}
                    onChange={(e) => updateName(index, e.target.value)}
                    className="name-input px-4 py-4 text-lg pr-12"
                    placeholder={`Enter ${index === 0 ? 'first' : index === 1 ? 'second' : index === 2 ? 'third' : 'fourth'} name`}
                    data-testid={`input-name-${index + 1}`}
                  />
                  <Label 
                    htmlFor={`name-${index + 1}`}
                    className="absolute -top-3 left-3 bg-card px-2 text-sm font-medium text-muted-foreground"
                  >
                    Name {index + 1} {index < 2 && <span className="text-primary">*</span>}
                  </Label>
                  
                  {/* Remove button for names beyond the first two */}
                  {index >= 2 && (
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-2 top-1/2 -translate-y-1/2 text-destructive hover:text-destructive"
                      onClick={() => removeName(index)}
                      data-testid={`button-remove-name-${index + 1}`}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Add Another Name Button */}
          {names.length < maxNames && (
            <Button
              type="button"
              variant="outline"
              className="w-full md:w-auto px-6 py-3 border-2 border-dashed border-primary/50 text-primary hover:bg-primary/5 mb-8"
              onClick={addName}
              data-testid="button-add-name"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Another Name
            </Button>
          )}

          {/* Generate Button */}
          <Button
            onClick={handleGenerate}
            disabled={isGenerating}
            className="gradient-bg w-full py-4 text-lg font-semibold hover:shadow-lg hover:scale-[1.02] transition-all duration-200"
            data-testid="button-generate"
          >
            <WandSparkles className="w-5 h-5 mr-3" />
            {isGenerating ? "Creating Combined Names..." : "Create Combined Names"}
          </Button>
        </div>
      </div>
    </section>
  );
}
