import { Copy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { NameCombination } from "@/lib/name-combiner";

interface CombinationResultsProps {
  combinations: NameCombination[];
  onCopyToClipboard: (text: string) => void;
}

export default function CombinationResults({ combinations, onCopyToClipboard }: CombinationResultsProps) {
  return (
    <section className="py-16 gradient-bg-light" data-testid="combination-results">
      <div className="container mx-auto px-4 max-w-6xl">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-serif font-bold mb-4">
            Your Perfect <span className="gradient-text">Name Combinations</span>
          </h2>
          <p className="text-muted-foreground mb-2">
            <span data-testid="text-combination-count">{combinations.length}</span> unique combinations generated
          </p>
          <p className="text-sm text-muted-foreground">
            Click any name to copy to clipboard
          </p>
        </div>

        {/* Combination Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4" data-testid="combinations-grid">
          {combinations.map((combo, index) => (
            <div
              key={`${combo.name}-${index}`}
              className="combination-card bg-white rounded-xl p-4 cursor-pointer border-2 border-border hover:border-primary transition-all"
              onClick={() => onCopyToClipboard(combo.name)}
              data-testid={`card-combination-${index}`}
            >
              <div className="text-center">
                <div className="text-2xl font-script text-primary mb-2" data-testid={`text-combination-name-${index}`}>
                  {combo.name}
                </div>
                <div className="text-xs text-muted-foreground mb-3" data-testid={`text-combination-description-${index}`}>
                  {combo.description}
                </div>
                <div className="flex items-center justify-center gap-2 text-xs text-muted-foreground">
                  <Copy className="w-3 h-3" />
                  <span>Click to copy</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {combinations.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground text-lg">
              No combinations generated. Please try different names.
            </p>
          </div>
        )}
      </div>
    </section>
  );
}
