import { useState } from "react";
import { Heart, Shield, Smartphone, WandSparkles, Users, Brain, Zap, BellRing, Share, Home as HomeIcon, CheckCircle, Info, Star, VolumeX, Copy, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import NameInputForm from "@/components/name-input-form";
import CombinationResults from "@/components/combination-results";
import FaqSection from "@/components/faq-section";
import { NameCombination } from "@/lib/name-combiner";
import { useToast } from "@/hooks/use-toast";

export default function Home() {
  const [combinations, setCombinations] = useState<NameCombination[]>([]);
  const [showResults, setShowResults] = useState(false);
  const { toast } = useToast();

  const handleCombinationsGenerated = (newCombinations: NameCombination[]) => {
    setCombinations(newCombinations);
    setShowResults(true);
    
    // Scroll to results section
    setTimeout(() => {
      const resultsSection = document.getElementById('results-section');
      if (resultsSection) {
        resultsSection.scrollIntoView({ behavior: 'smooth' });
      }
    }, 100);
  };

  const handleCopyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast({
        title: "Copied to clipboard!",
        description: `"${text}" has been copied to your clipboard.`,
      });
    } catch (err) {
      toast({
        title: "Copy failed",
        description: "Unable to copy to clipboard. Please try selecting and copying manually.",
        variant: "destructive",
      });
    }
  };

  const scrollToNameInput = () => {
    const nameInputSection = document.getElementById('name-input-section');
    if (nameInputSection) {
      nameInputSection.scrollIntoView({ behavior: 'smooth', block: 'center' });
      // Focus on first input
      setTimeout(() => {
        const firstInput = document.getElementById('name-1');
        if (firstInput) {
          firstInput.focus();
        }
      }, 500);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-primary/10 via-accent/20 to-secondary/10 py-16 md:py-24">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-10 left-10 w-72 h-72 bg-primary/30 rounded-full blur-3xl"></div>
          <div className="absolute bottom-10 right-10 w-96 h-96 bg-secondary/30 rounded-full blur-3xl"></div>
        </div>
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center max-w-4xl mx-auto">
            <h1 className="text-4xl md:text-6xl font-serif font-bold mb-6 leading-tight">
              Create Beautiful <span className="gradient-text">Combined Names</span> for Couples
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Perfect for wedding hashtags, couple names, and memorable combinations. Our advanced algorithm generates up to 100 unique variations that honor both partners.
            </p>
            <div className="flex flex-wrap gap-4 justify-center">
              <div className="flex items-center gap-2 bg-white/80 backdrop-blur-sm px-4 py-2 rounded-full">
                <Heart className="w-4 h-4 text-primary" />
                <span className="text-sm font-medium">100+ Combinations</span>
              </div>
              <div className="flex items-center gap-2 bg-white/80 backdrop-blur-sm px-4 py-2 rounded-full">
                <Shield className="w-4 h-4 text-secondary" />
                <span className="text-sm font-medium">Privacy First</span>
              </div>
              <div className="flex items-center gap-2 bg-white/80 backdrop-blur-sm px-4 py-2 rounded-full">
                <Smartphone className="w-4 h-4 text-primary" />
                <span className="text-sm font-medium">Mobile Friendly</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Name Input Section */}
      <section id="name-input-section" data-testid="name-input-section">
        <NameInputForm onCombinationsGenerated={handleCombinationsGenerated} />
      </section>

      {/* Results Section */}
      {showResults && (
        <section id="results-section" data-testid="results-section">
          <CombinationResults 
            combinations={combinations} 
            onCopyToClipboard={handleCopyToClipboard}
          />
        </section>
      )}

      {/* Understanding Section */}
      <section className="py-16 bg-background" data-testid="understanding-section">
        <div className="container mx-auto px-4 max-w-6xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-serif font-bold mb-4">
              Understanding <span className="gradient-text">Name Combinations</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              A combined name is more than just merging letters—it's about creating a shared identity that honors both individuals.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Feature 1 */}
            <div className="feature-card bg-card rounded-2xl p-8 shadow-lg border border-border hover:shadow-xl transition-shadow">
              <div className="feature-icon w-16 h-16 gradient-bg rounded-2xl flex items-center justify-center mb-6">
                <Heart className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-serif font-semibold mb-3">Meaningful</h3>
              <p className="text-muted-foreground">
                Each combination preserves key elements from both original names, ensuring the result feels personal and connected to both partners.
              </p>
            </div>

            {/* Feature 2 */}
            <div className="feature-card bg-card rounded-2xl p-8 shadow-lg border border-border hover:shadow-xl transition-shadow">
              <div className="feature-icon w-16 h-16 gradient-bg rounded-2xl flex items-center justify-center mb-6">
                <VolumeX className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-serif font-semibold mb-3">Pronounceable</h3>
              <p className="text-muted-foreground">
                Our algorithm balances consonants and vowels to create names that flow naturally and are easy to say.
              </p>
            </div>

            {/* Feature 3 */}
            <div className="feature-card bg-card rounded-2xl p-8 shadow-lg border border-border hover:shadow-xl transition-shadow">
              <div className="feature-icon w-16 h-16 gradient-bg rounded-2xl flex items-center justify-center mb-6">
                <Star className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-serif font-semibold mb-3">Memorable</h3>
              <p className="text-muted-foreground">
                Generated names maintain a length of 3-12 characters, making them easy to remember and use in daily life.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Smart Features */}
      <section className="py-16 gradient-bg-light" data-testid="smart-features-section">
        <div className="container mx-auto px-4 max-w-6xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-serif font-bold mb-4">
              Smart <span className="gradient-text">Features</span>
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Feature 1 */}
            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-6">
                <Users className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Multiple Name Support</h3>
              <p className="text-muted-foreground">
                Combine up to four names to include middle names or create family combinations. Perfect for blending family identities.
              </p>
            </div>

            {/* Feature 2 */}
            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <div className="w-12 h-12 bg-secondary/10 rounded-xl flex items-center justify-center mb-6">
                <Brain className="w-6 h-6 text-secondary" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Intelligent Generation</h3>
              <p className="text-muted-foreground">
                Our algorithm analyzes name patterns, syllables, and sound combinations to create harmonious blends.
              </p>
            </div>

            {/* Feature 3 */}
            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-6">
                <Zap className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Instant Variations</h3>
              <p className="text-muted-foreground">
                Get up to 100 unique combinations instantly, sorted by quality and meaningfulness.
              </p>
            </div>
          </div>

          <div className="mt-8 bg-accent/30 rounded-2xl p-6 border border-primary/20">
            <div className="flex items-start gap-4">
              <Info className="w-6 h-6 text-primary mt-1 flex-shrink-0" />
              <div>
                <p className="text-foreground">
                  <strong>Pro Tip:</strong> For best results, enter full names rather than nicknames. This gives our algorithm more patterns to work with, especially for creating couple name combinations for Instagram.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Perfect For Section */}
      <section className="py-16 bg-background" data-testid="perfect-for-section">
        <div className="container mx-auto px-4 max-w-6xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-serif font-bold mb-4">
              Perfect <span className="gradient-text">For</span>
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Use Case 1 */}
            <div className="bg-card rounded-2xl overflow-hidden shadow-lg border border-border hover:shadow-xl transition-shadow">
              <div className="h-48 bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center">
                <BellRing className="w-16 h-16 text-primary" />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-3">Wedding Planning</h3>
                <p className="text-muted-foreground mb-4">
                  Create unique hashtags, shared email addresses, or new family names for your wedding celebration. Your one place name combination for wedding tool.
                </p>
                <div className="flex items-center gap-2 text-primary text-sm">
                  <CheckCircle className="w-4 h-4" />
                  <span>Wedding hashtags</span>
                </div>
              </div>
            </div>

            {/* Use Case 2 */}
            <div className="bg-card rounded-2xl overflow-hidden shadow-lg border border-border hover:shadow-xl transition-shadow">
              <div className="h-48 bg-gradient-to-br from-secondary/20 to-primary/20 flex items-center justify-center">
                <Share className="w-16 h-16 text-secondary" />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-3">Social Media</h3>
                <p className="text-muted-foreground mb-4">
                  Find creative couple names for joint social media accounts or special announcements.
                </p>
                <div className="flex items-center gap-2 text-secondary text-sm">
                  <CheckCircle className="w-4 h-4" />
                  <span>Instagram usernames</span>
                </div>
              </div>
            </div>

            {/* Use Case 3 */}
            <div className="bg-card rounded-2xl overflow-hidden shadow-lg border border-border hover:shadow-xl transition-shadow">
              <div className="h-48 bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center">
                <HomeIcon className="w-16 h-16 text-primary" />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-3">Family Blending</h3>
                <p className="text-muted-foreground mb-4">
                  Explore options for combining family names in meaningful ways when joining families together.
                </p>
                <div className="flex items-center gap-2 text-primary text-sm">
                  <CheckCircle className="w-4 h-4" />
                  <span>New family names</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 gradient-bg-light" data-testid="how-it-works-section">
        <div className="container mx-auto px-4 max-w-6xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-serif font-bold mb-4">
              How It <span className="gradient-text">Works</span>
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Step 1 */}
            <div className="relative">
              <div className="bg-white rounded-2xl p-8 shadow-lg">
                <div className="absolute -top-4 -left-4 w-12 h-12 gradient-bg rounded-full flex items-center justify-center text-white font-bold text-xl">
                  1
                </div>
                <div className="mt-4">
                  <h3 className="text-xl font-semibold mb-3">Name Analysis</h3>
                  <p className="text-muted-foreground">
                    Our tool analyzes the structure, sounds, and patterns in each name you enter.
                  </p>
                </div>
              </div>
            </div>

            {/* Step 2 */}
            <div className="relative">
              <div className="bg-white rounded-2xl p-8 shadow-lg">
                <div className="absolute -top-4 -left-4 w-12 h-12 gradient-bg rounded-full flex items-center justify-center text-white font-bold text-xl">
                  2
                </div>
                <div className="mt-4">
                  <h3 className="text-xl font-semibold mb-3">Pattern Matching</h3>
                  <p className="text-muted-foreground">
                    The algorithm identifies compatible sound combinations and meaningful segments from each name.
                  </p>
                </div>
              </div>
            </div>

            {/* Step 3 */}
            <div className="relative">
              <div className="bg-white rounded-2xl p-8 shadow-lg">
                <div className="absolute -top-4 -left-4 w-12 h-12 gradient-bg rounded-full flex items-center justify-center text-white font-bold text-xl">
                  3
                </div>
                <div className="mt-4">
                  <h3 className="text-xl font-semibold mb-3">Quality Check</h3>
                  <p className="text-muted-foreground">
                    Each combination is evaluated for pronunciation, length, and overall appeal before being presented.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-8 bg-white rounded-2xl p-6 border border-primary/20">
            <div className="flex items-start gap-4">
              <Info className="w-6 h-6 text-primary mt-1 flex-shrink-0" />
              <div>
                <p className="text-foreground">
                  <strong>Tip:</strong> Try different name variations to get more wedding name combination options. You can include middle names or family names for more possibilities.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Tips for Success */}
      <section className="py-16 bg-background" data-testid="tips-section">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-serif font-bold mb-4">
              Tips for <span className="gradient-text">Success</span>
            </h2>
          </div>

          <div className="bg-card rounded-2xl shadow-lg p-8 md:p-12 border border-border">
            <div className="space-y-6">
              {[
                {
                  title: "Start with full, formal names",
                  description: "Use complete names rather than nicknames for better results and more varied combinations."
                },
                {
                  title: "Try different name combinations", 
                  description: "If you have multiple names (first, middle, last), experiment with different combinations."
                },
                {
                  title: "Consider both personal and professional use",
                  description: "Think about where you'll use the combined name when making your selection."
                },
                {
                  title: "Test pronunciation with friends and family",
                  description: "Say the combinations out loud and get feedback before making a final decision."
                },
                {
                  title: "Save multiple favorites",
                  description: "Use the copy button to save several options and review them later with your partner."
                }
              ].map((tip, index) => (
                <div key={index} className="flex items-start gap-4">
                  <div className="w-8 h-8 gradient-bg rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <CheckCircle className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">{tip.title}</h4>
                    <p className="text-muted-foreground">{tip.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Success Stories */}
      <section className="py-16 gradient-bg-light" data-testid="success-stories-section">
        <div className="container mx-auto px-4 max-w-6xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-serif font-bold mb-4">
              Success <span className="gradient-text">Stories</span>
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Story 1 */}
            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 gradient-bg rounded-full flex items-center justify-center">
                  <span className="text-white text-xl">#</span>
                </div>
                <h3 className="text-lg font-semibold">The Wedding Hashtag</h3>
              </div>
              <p className="text-muted-foreground mb-4">
                Sarah Chen and Michael Rodriguez used their combined name "Chenriguez" for their wedding hashtag, creating a unique way for guests to share photos.
              </p>
              <div className="text-sm text-primary font-medium">
                #Chenriguez2024
              </div>
            </div>

            {/* Story 2 */}
            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 gradient-bg rounded-full flex items-center justify-center">
                  <HomeIcon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-lg font-semibold">The Family Blend</h3>
              </div>
              <p className="text-muted-foreground mb-4">
                The Thompson-Williams family created "Willson" as their new shared name, honoring both family histories while starting fresh.
              </p>
              <div className="text-sm text-primary font-medium">
                The Willson Family
              </div>
            </div>

            {/* Story 3 */}
            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 gradient-bg rounded-full flex items-center justify-center">
                  <Heart className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-lg font-semibold">The Social Couple</h3>
              </div>
              <p className="text-muted-foreground mb-4">
                Amy and Jordan found "Jormy" through our tool, which became their popular couple account name across social platforms.
              </p>
              <div className="text-sm text-primary font-medium">
                @JormyAdventures
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <FaqSection />

      {/* Technical Notes */}
      <section className="py-16 gradient-bg-light" data-testid="technical-notes-section">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12 border border-border">
            <h2 className="text-2xl font-serif font-bold mb-6">Technical Notes</h2>
            
            <div className="mb-6">
              <h3 className="font-semibold mb-3">Our name combination algorithm considers:</h3>
              <ul className="space-y-2">
                {[
                  "Phonetic patterns and sound combinations",
                  "Syllable structure and stress patterns", 
                  "Vowel-consonant balance",
                  "Cultural naming patterns",
                  "Pronunciation guidelines"
                ].map((item, index) => (
                  <li key={index} className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-primary mt-1 flex-shrink-0" />
                    <span className="text-muted-foreground">{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-accent/30 rounded-xl p-6 border border-primary/20">
              <div className="flex items-start gap-3">
                <Shield className="w-5 h-5 text-primary mt-1 flex-shrink-0" />
                <div>
                  <h4 className="font-semibold mb-2">Privacy First</h4>
                  <p className="text-sm text-muted-foreground">
                    Names are stored locally in your browser for privacy. No personal information is sent to our servers.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-background" data-testid="cta-section">
        <div className="container mx-auto px-4 max-w-4xl text-center">
          <div className="gradient-bg rounded-2xl p-12 shadow-xl">
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-white mb-4">
              Ready to Create Your Perfect Name?
            </h2>
            <p className="text-white/90 mb-8 text-lg">
              Start combining names and discover beautiful possibilities for your relationship
            </p>
            <Button 
              size="lg"
              className="bg-white text-primary hover:bg-white/90 px-8 py-4 text-lg font-semibold"
              onClick={scrollToNameInput}
              data-testid="button-get-started"
            >
              Get Started Now
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card border-t border-border py-8" data-testid="footer">
        <div className="container mx-auto px-4">
          <div className="text-center text-muted-foreground">
            <p className="mb-2">© 2024 Couple Name Combiner. Created with <Heart className="inline w-4 h-4 text-primary" /> for couples everywhere.</p>
            <p className="text-sm">All processing happens locally in your browser. Your privacy is our priority.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
