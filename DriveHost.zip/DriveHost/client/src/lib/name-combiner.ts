export interface NameCombination {
  name: string;
  description: string;
  score?: number;
}

export function generateCombinations(names: string[]): NameCombination[] {
  const validNames = names.filter(n => n && n.trim().length > 0).map(n => n.trim());
  
  if (validNames.length < 2) {
    return [];
  }

  const combos: NameCombination[] = [];
  const used = new Set<string>();

  // Helper function to check if combination is valid
  function isValidCombo(combo: string): boolean {
    return combo.length >= 3 && combo.length <= 12 && !used.has(combo.toLowerCase());
  }

  // Helper function to add combination with scoring
  function addCombo(combo: string, desc: string, score: number = 0): void {
    const lower = combo.toLowerCase();
    if (isValidCombo(combo) && !used.has(lower)) {
      used.add(lower);
      combos.push({ 
        name: capitalizeFirst(combo), 
        description: desc,
        score 
      });
    }
  }

  // Helper function to capitalize first letter
  function capitalizeFirst(str: string): string {
    return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
  }

  // Helper function to calculate combination quality score
  function calculateScore(combo: string): number {
    let score = 0;
    
    // Prefer names close to 6-8 characters (ideal length)
    const lengthScore = Math.max(0, 10 - Math.abs(combo.length - 7));
    score += lengthScore;
    
    // Bonus for vowel-consonant balance
    const vowels = combo.match(/[aeiouAEIOU]/g) || [];
    const consonants = combo.match(/[bcdfghjklmnpqrstvwxyzBCDFGHJKLMNPQRSTVWXYZ]/g) || [];
    const vowelRatio = vowels.length / combo.length;
    if (vowelRatio >= 0.2 && vowelRatio <= 0.5) {
      score += 5;
    }
    
    // Bonus for pronounceability patterns
    if (!combo.match(/[bcdfghjklmnpqrstvwxyz]{4,}/i)) {
      score += 3; // No more than 3 consecutive consonants
    }
    
    return score;
  }

  // Generate combinations for each pair of names
  for (let i = 0; i < validNames.length; i++) {
    for (let j = i + 1; j < validNames.length; j++) {
      const name1 = validNames[i];
      const name2 = validNames[j];
      
      // Method 1: Prefix + Suffix combinations (most common)
      for (let k = 1; k < name1.length; k++) {
        for (let l = 1; l < name2.length; l++) {
          const combo1 = name1.slice(0, k) + name2.slice(l);
          const combo2 = name2.slice(0, k) + name1.slice(l);
          
          addCombo(combo1, `${name1} + ${name2}`, calculateScore(combo1));
          addCombo(combo2, `${name2} + ${name1}`, calculateScore(combo2));
        }
      }

      // Method 2: Syllable-based combinations
      const mid1 = Math.floor(name1.length / 2);
      const mid2 = Math.floor(name2.length / 2);
      
      const sylCombo1 = name1.slice(0, mid1) + name2.slice(mid2);
      const sylCombo2 = name2.slice(0, mid2) + name1.slice(mid1);
      
      addCombo(sylCombo1, `${name1} + ${name2}`, calculateScore(sylCombo1) + 2);
      addCombo(sylCombo2, `${name2} + ${name1}`, calculateScore(sylCombo2) + 2);

      // Method 3: Vowel-based combinations
      const vowels = 'aeiouAEIOU';
      let name1Consonants = name1.replace(/[aeiouAEIOU]/g, '');
      let name2Consonants = name2.replace(/[aeiouAEIOU]/g, '');
      let name1Vowels = name1.replace(/[^aeiouAEIOU]/g, '');
      let name2Vowels = name2.replace(/[^aeiouAEIOU]/g, '');

      if (name1Consonants.length > 1 && name2Vowels.length > 0) {
        const vowelCombo1 = name1Consonants.slice(0, 2) + name2Vowels.slice(0, 2) + name2.slice(-2);
        addCombo(vowelCombo1, `${name1} + ${name2}`, calculateScore(vowelCombo1));
      }

      if (name2Consonants.length > 1 && name1Vowels.length > 0) {
        const vowelCombo2 = name2Consonants.slice(0, 2) + name1Vowels.slice(0, 2) + name1.slice(-2);
        addCombo(vowelCombo2, `${name2} + ${name1}`, calculateScore(vowelCombo2));
      }

      // Method 4: First and last letter combinations
      const firstLast1 = name1.slice(0, 3) + name2.slice(-3);
      const firstLast2 = name2.slice(0, 3) + name1.slice(-3);
      
      addCombo(firstLast1, `${name1} + ${name2}`, calculateScore(firstLast1) + 1);
      addCombo(firstLast2, `${name2} + ${name1}`, calculateScore(firstLast2) + 1);

      // Method 5: Overlapping combinations (when names share letters)
      for (let k = 1; k <= Math.min(3, name1.length - 1, name2.length - 1); k++) {
        const name1End = name1.slice(-k).toLowerCase();
        const name2Start = name2.slice(0, k).toLowerCase();
        
        if (name1End === name2Start) {
          const overlap = name1 + name2.slice(k);
          addCombo(overlap, `${name1} + ${name2}`, calculateScore(overlap) + 5);
        }
        
        const name2End = name2.slice(-k).toLowerCase();
        const name1Start = name1.slice(0, k).toLowerCase();
        
        if (name2End === name1Start) {
          const overlap = name2 + name1.slice(k);
          addCombo(overlap, `${name2} + ${name1}`, calculateScore(overlap) + 5);
        }
      }

      // Method 6: Phonetic combinations (similar sounds)
      const phoneticPairs = [
        ['ph', 'f'], ['ck', 'k'], ['ch', 'sh'], ['th', 't'],
        ['tion', 'shun'], ['sion', 'zhun']
      ];

      phoneticPairs.forEach(([pattern, replacement]) => {
        if (name1.toLowerCase().includes(pattern) || name2.toLowerCase().includes(pattern)) {
          const phoneticCombo = (name1 + name2).replace(new RegExp(pattern, 'gi'), replacement);
          if (phoneticCombo !== name1 + name2 && phoneticCombo.length >= 3 && phoneticCombo.length <= 12) {
            addCombo(phoneticCombo, `${name1} + ${name2}`, calculateScore(phoneticCombo) + 3);
          }
        }
      });
    }
  }

  // If we have 3+ names, create some triple combinations
  if (validNames.length >= 3) {
    const initials = validNames.map(n => n.charAt(0)).join('');
    addCombo(initials + validNames[0].slice(1, 3), validNames.join(' + '), calculateScore(initials) + 4);
    
    // Mix first name with parts of other names
    const firstName = validNames[0];
    const otherNames = validNames.slice(1);
    const mixedSuffix = otherNames.map(n => n.slice(0, 2)).join('');
    addCombo(firstName.slice(0, 3) + mixedSuffix, validNames.join(' + '), calculateScore(firstName + mixedSuffix));
  }

  // Sort by score (highest first), then by length preference
  combos.sort((a, b) => {
    const scoreA = a.score || 0;
    const scoreB = b.score || 0;
    
    if (scoreB !== scoreA) {
      return scoreB - scoreA;
    }
    
    // Secondary sort: prefer length around 6-8 characters
    const lengthScoreA = Math.abs(a.name.length - 7);
    const lengthScoreB = Math.abs(b.name.length - 7);
    
    return lengthScoreA - lengthScoreB;
  });

  // Return top 100 combinations
  return combos.slice(0, 100);
}

// Additional utility functions for name analysis
export function analyzeNameCompatibility(names: string[]): {
  compatibility: number;
  suggestions: string[];
} {
  if (names.length < 2) {
    return { compatibility: 0, suggestions: ['Please provide at least 2 names'] };
  }

  const validNames = names.filter(n => n && n.trim().length > 0);
  let compatibility = 0;
  const suggestions: string[] = [];

  // Check for shared letters
  const sharedLetters = findSharedLetters(validNames);
  compatibility += sharedLetters.length * 5;

  // Check length compatibility
  const lengths = validNames.map(n => n.length);
  const avgLength = lengths.reduce((a, b) => a + b, 0) / lengths.length;
  const lengthVariance = lengths.reduce((sum, len) => sum + Math.pow(len - avgLength, 2), 0) / lengths.length;
  
  if (lengthVariance < 4) {
    compatibility += 10;
  }

  // Provide suggestions
  if (sharedLetters.length > 0) {
    suggestions.push(`Great! Your names share these letters: ${sharedLetters.join(', ')}`);
  }

  if (validNames.some(name => name.length > 8)) {
    suggestions.push('Consider using shorter versions of longer names for better combinations');
  }

  return { compatibility: Math.min(100, compatibility), suggestions };
}

function findSharedLetters(names: string[]): string[] {
  if (names.length < 2) return [];
  
  const letterSets = names.map(name => new Set(name.toLowerCase().split('')));
  const shared = letterSets[0];
  
  for (let i = 1; i < letterSets.length; i++) {
    const current = letterSets[i];
    for (const letter of shared) {
      if (!current.has(letter)) {
        shared.delete(letter);
      }
    }
  }
  
  return Array.from(shared).filter(letter => letter.match(/[a-z]/));
}
