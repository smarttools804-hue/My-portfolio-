# Couple Name Combiner Application

## Overview

This is a web application that generates creative name combinations for couples. Users can input 2-4 names and the system generates up to 100 unique, phonetically pleasing combinations. The application features a modern, romantic UI built with React and styled using Tailwind CSS with shadcn/ui components. The backend is prepared for future API integration with Express.js, though the current name generation logic runs entirely client-side.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Technology Stack:**
- React 18 with TypeScript for type safety
- Vite as the build tool and development server
- Wouter for lightweight client-side routing
- TanStack Query (React Query) for future API state management

**UI Framework:**
- shadcn/ui component library built on Radix UI primitives
- Tailwind CSS for styling with custom design tokens
- Custom theme with romantic color palette (pinks, purples)
- Multiple custom font families (Playfair Display, Inter, Dancing Script)

**Key Design Decisions:**
1. **Client-Side Name Generation:** The name combination algorithm (`lib/name-combiner.ts`) runs entirely in the browser, eliminating server dependencies for core functionality. This provides instant feedback and works offline.
2. **Local Storage Persistence:** User inputs are automatically saved to browser localStorage via the `useLocalStorage` hook, preserving state across sessions without requiring authentication.
3. **Component Architecture:** Follows a modular approach with dedicated components for name input form, combination results display, and FAQ section. Each component is self-contained and reusable.

**State Management:**
- React hooks (useState, useEffect) for local component state
- Custom `useLocalStorage` hook for persistent state
- TanStack Query configured for future API integration with optimistic updates

### Backend Architecture

**Technology Stack:**
- Node.js with Express.js framework
- TypeScript for type-safe server code
- ESM module system

**Server Structure:**
1. **Modular Setup:** Server entry point (`server/index.ts`) initializes Express with JSON parsing, request logging, and development/production mode handling.
2. **Route Registration:** The `registerRoutes` function in `server/routes.ts` is prepared for REST API endpoints (prefixed with `/api`).
3. **Storage Layer:** An abstraction layer (`server/storage.ts`) defines an `IStorage` interface with CRUD operations. Currently implements `MemStorage` (in-memory storage) as a placeholder for future database integration.
4. **Vite Integration:** In development, the server proxies requests through Vite for HMR (Hot Module Replacement). In production, it serves pre-built static assets.

**Architectural Decisions:**
1. **Storage Abstraction:** The `IStorage` interface allows swapping between in-memory storage and database implementations without changing application code.
2. **API-Ready Structure:** Routes are organized to accept future endpoints for saving favorite combinations, user preferences, or analytics.
3. **Development Experience:** Integration with Replit-specific Vite plugins provides runtime error overlays and development tooling.

### Data Layer

**Database Configuration:**
- Drizzle ORM configured for PostgreSQL
- Schema defined in `shared/schema.ts` with a users table (id, username, password)
- Migration support via Drizzle Kit

**Current Implementation:**
1. **In-Memory Storage:** The `MemStorage` class provides a temporary storage solution using JavaScript Maps. This is suitable for development but not production.
2. **Database Schema:** A minimal user authentication schema is defined but not yet utilized. The schema uses Drizzle-Zod for validation.
3. **Future Database Integration:** The architecture is prepared for connecting to Neon PostgreSQL (via `@neondatabase/serverless`), requiring only environment variable configuration.

**Design Rationale:**
- The storage interface allows the application to function without a database during initial development
- When database features are needed, the switch requires minimal code changes (swap `MemStorage` for a database implementation)
- Drizzle ORM provides type-safe database queries and automatic migration generation

### External Dependencies

**Database:**
- Neon PostgreSQL (configured but not yet connected)
- Connection via `@neondatabase/serverless` driver
- Drizzle ORM (v0.39.1) for type-safe queries
- Connection string expected in `DATABASE_URL` environment variable

**UI Component Libraries:**
- Radix UI primitives (v1.x for most components) - unstyled, accessible components
- shadcn/ui configuration (New York style)
- Embla Carousel for potential image carousels
- cmdk for command palette functionality

**Form Handling:**
- React Hook Form (via @hookform/resolvers v3.10.0)
- Zod schema validation
- Drizzle-Zod for database schema validation

**Styling:**
- Tailwind CSS v3+ with custom configuration
- PostCSS with autoprefixer
- class-variance-authority for component variant management
- clsx and tailwind-merge for className management

**Build Tools:**
- Vite 5.x for development server and production builds
- esbuild for server-side bundling
- TypeScript 5.x for type checking
- tsx for running TypeScript files directly

**Development Tools (Replit-specific):**
- `@replit/vite-plugin-runtime-error-modal` - Error overlays in development
- `@replit/vite-plugin-cartographer` - Code navigation tools
- `@replit/vite-plugin-dev-banner` - Development environment indicators

**Session Management:**
- `connect-pg-simple` configured for PostgreSQL session storage (not yet implemented)

**Utilities:**
- date-fns for date formatting and manipulation
- nanoid for unique ID generation
- Various Lucide React icons throughout the UI